package com.imdd.reliquias.mixin;

import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.assets.mixin.Mixin;

@Mixin(ServerPlayerEntity.class)
public class ServerPlayerEntityMixin {
}
