package com.imdd.reliquias.command;

import com.imdd.reliquias.gui.RelicGuiScreenHandler;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Formatting;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

public class ReliquiasCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("relics")
                .requires(source -> source.hasPermissionLevel(2))
                .executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    openGui(player);
                    return 1;
                }));
    }

    public static void openGui(ServerPlayerEntity player) {
        Text title = Text.literal("IMDD").setStyle(
                        Style.EMPTY.withColor(TextColor.fromRgb(0x8B5CF6)).withBold(true)
                )
                .append(Text.literal("» ").setStyle(Style.EMPTY.withColor(Formatting.GRAY).withBold(false)))
                .append(Text.literal("Relíquia").setStyle(Style.EMPTY.withColor(Formatting.DARK_GRAY).withBold(false)));

        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, inv, p) -> new RelicGuiScreenHandler(syncId, inv, player),
                title
        ));
    }
}
